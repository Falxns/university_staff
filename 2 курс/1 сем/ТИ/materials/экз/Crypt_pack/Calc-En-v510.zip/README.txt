=====================================================================
Safe Calculator v5.10
=====================================================================

CONTENTS

1) Sp�cifications
2) Description
3) Directions for use
4) Additional notes
5) Installation
6) Portability
7) Support

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

1) SPECIFICATIONS
-----------------
 date     : 22/03/09
 file     : Calc.exe
 size     : 225 Ko
 OS       : Win 95,98,NT,2000,XP,Vista
 language : English
 license  : Freeware
 author   : Christophe Laing
 Website  : http://www.krilome.com

2) DESCRIPTION
--------------
 This calculator, clone of Windows version, is in fact a mini safe protected by a secret code.
 It stores encrypted, or restores, the file you'll have choosen.

 Under the appearance of a commmon calculator, you can from now on transfer onto your key USB,
 of the confidential informations (identifiers, passwords,�) without fear of consequences in
 the event of loss or flight and without needing to move you with your software of encoding.

 [ This Safe Calculator does not contain spyware, adware, or malware or other virus ]

3) DIRECTION FOR USE
--------------------
 Type your secret code, then store it in memory [button MS], this calulator turn to safe mode.
 Browse directories and choose a file. The Safe Calculator will stored it encrypted in its own
 executable file. Clear the memory [button MC], this safe become a common calculator again.
 Now after store your secret code in memory, you can restore, extract, display or update the stored file.

 <<<< The default secret code is 123 >>>

 Your new PIN must be a figure from 1 to 32 numbers, positive or negative, integer or decimal! 
 For more help and description of all commands, click on Help button (or key F1) in Safe mode.

4) ADDITIONAL NOTES
-------------------
- Only text files are encrypted so as not to be read by a hex editor.
- During storage of the file or secret code, the calculator disappears for a few milliseconds,
  this operation is quite normal due to the correction of its own executable file.
- The storage of a big file works perfectly, but a calculator several mega bytes is significantly less "trivial".

5) INSTALLATION
---------------
 No install required. Just extract the executable file to any folder of your choice, then run "Calc.exe".

6) PORTABILITY
--------------
 No modification of the registry is made.
 All file changes are made in the working directory.

7) SUPPORT
----------
- In case of malfunction, or missing files errors, go to Support page on the web site.
- Forget your secret code ? contact me.